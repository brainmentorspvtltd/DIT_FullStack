import { UserModel } from "../models/user-schema"

// DB CRUD Operations
export const userService = {
    async register(user){
        try{
        const doc = await UserModel.create(user);
        return doc;
        }
        catch(err){
            console.log('Unable to Register ', err);
            throw err;
        }
    },
    login(){

    }
}