// Bridge file (connect App.js(root component ) with index.html)
// VDOM (Component) Map to the DOM
import ReactDOM from 'react-dom/client';
import App from './App';
const div = document.querySelector('#root'); // DOM
const root = ReactDOM.createRoot(div);
root.render(<App/>); // VDOM map DOM