export const Second = ()=>{
    const products = [
        {id:1001, name:'Mobile', price:9000},
        {id:1002, name:'LED', price:29000},
        {id:1003, name:'Shoes', price:2000}
    ];

    const fruits = ['Apple', 'Orange', 'Mango'];
    return (<>
    <h1>Iterative Rendering....</h1>
            {/* {fruits.map(fruit=>{
                return (<p>Fruit is {fruit}</p>);
            })} */}
            <hr/>
            <table border="1">
                <thead>
                <tr>
                    <td>Id</td>
                    <td>Name</td>
                    <td>Price</td>
                </tr>
                </thead>
                <tbody>            
                    <>{products.map((product,index)=>
                // (<tr key={product.id}>
                (<tr key={index}>
                    <td>{product.id}</td>
                    <td>{product.name}</td>
                    <td>{product.price}</td>
                </tr>)
                
                 //(<p>Id {product.id} {product.name} {product.price}</p>)
            )}
            </>
            </tbody>

             </table>
    </>)
}