import React from 'react';
import './First.css';
export const First = ()=>{
    const myStyle = {
        color:'orange',
        backgroundColor:'cyan'
    }
    const price = 900;
    const weakPwd = true;
    const myName = 'AMIT SRIVASTAVA'
    const logic = (val)=>{
        if(val>100){
            return (<>
                <p>First Value</p>
                <p>Second Value</p>
            </>)
        }
        else{
            return (<>
                 <p>Second Value</p>
                <p>First Value</p>
            </>)
        }
    }
    return (<>
    <h3 className="red">My First Component {myName}</h3>
    <p style={myStyle}>This is Example </p>
    {price>5000?<p>Discount 10%</p>:<p>No Discount</p>}
     {weakPwd && <><h1>Must be AlphaNumeric</h1>
     <h2>Must Contains Upper Lower Mix</h2>
     </>}   
     <hr/>
     {logic(1000)}
    </>
    )
}