// First Component / Root Component
// Arrow Function

import React from "react";
import { First } from "./components/First";
import { Second } from "./components/Second";

const App = ()=>{
  // JSX (JavaScript and XML)
  return (<div>
            <h1>Hello react js </h1>
            <h2>hi react js</h2>
            <First/>
            <Second/>
      </div>)
  //return (<h1>Hello react js</h1>)
  // return React.createElement('div', 
  // null, 
  // React.createElement('h1',null, 'Hello React JS'),
  // React.createElement('h2', null, 'Hi React JS'));
}
export default App;
