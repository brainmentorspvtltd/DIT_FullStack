import http from 'http';
import dotenv from 'dotenv';
import chalk from 'chalk';
import { isStaticContent, serveStaticContent } from './serve-content.js';
function handleRequestAndResponse(request, response){
    const urlString = request.url; // /
    
    if(urlString==='/'){
        serveStaticContent('index.html', response);
    }
    else if(isStaticContent(urlString)){
        serveStaticContent(urlString, response);
    }
    else {
    console.log('Request Rec ', request.url);
    response.write('<h1>Hello Client </h1>');
    response.end();
    }
}
const server = http.createServer(handleRequestAndResponse);
dotenv.config();
// console.log(process.env);
const serverInfo = server.listen(process.env.PORTNO || 3333,err=>{
    if(err){
        //console.log('Server Crash ', err);
        console.log(chalk.red.bold('Server Crash Happens.... '), err);
    }
    else{
        console.log(chalk.green.bold.underline('Server Up and Running '), serverInfo.address().port);
        //console.log('Server Up and Running ', serverInfo.address().port);
    }
})