// Represent an Application 
// https://dontpad.com/dit-code
import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import morgan from 'morgan';
import cors from 'cors';
import { createConnection } from './src/shared/db/connection.js';
import { userRoute } from './src/modules/user/routes/user-route.js';
import { errorHandler } from './src/shared/middlewares/error-handler.js';
import { serverLogStream } from './src/shared/logs/server-log.js';
process.on('uncaughtException', err=>{
    // Send Mail
    console.log('Some Issue Arrive ', err);
});
//x++;
const app = express();
app.use(cors());
dotenv.config();



app.use(morgan('combined',{stream:serverLogStream()}));

app.use(express.json()); 
app.use('/', userRoute);

// Attach Error Handler Middleware
app.use(errorHandler);


const promise = createConnection();
promise.then(data=>{
    console.log('DB Connection Done...');
    app.listen(1234,err=>{
        if(err){
            console.log('Server Crash ', err);
        }
        else{
            console.log('Server Up and Running');
        }
    })
}).catch(err=>{
    console.log('Error in DB Connection ', err);
})

// app.use(middleware);
// middleware - function (req, res, next)
