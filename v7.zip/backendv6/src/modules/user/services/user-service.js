import { messages } from "../../../shared/i18n/en.js";
import { compareHash, passwordHashing } from "../../../shared/services/encrypt.js";
import { generateToken } from "../../../shared/services/token.js";
import { UserModel } from "../models/user-schema.js"

// DB CRUD Operations
export const userService = {
    async register(user){
        try{
        user.password = passwordHashing(user.password );
            
        const doc = await UserModel.create(user);
        return doc;
        }
        catch(err){
            console.log('Unable to Register ', err);
            throw err;
        }
    },
    async login(user){
          const doc = await UserModel.
          findOne({'email':user.email}).
          lean().exec();  
          if(doc && doc.email){
            if(compareHash(user.password, doc.password)){
                const token = generateToken(user);
                return {message:messages['login-success']+doc.name,
                 success:true, token:token};
            }
            else{
                return {message:messages['login-failed'], success:false}  
            }
          }
          else{
            return {message:messages['login-failed'], success:false}
          }
    }
}