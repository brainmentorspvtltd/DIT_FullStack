import { myLogger } from "../../../shared/logs/app-logs.js";
import { userService } from "../services/user-service.js";

export const login = async(request, response, next)=>{
    const logger = myLogger('user-controller.js');
    try{
        logger.debug('Inside Login Controller ');
    const user = request.body;
    const doc = await userService.login(user);
    response.status(200).json(doc);
    logger.debug('Inside Login Controller Code Ends ');
    }
    catch(err){
        
       next(err); // call another middleware
        // response.status(500).json({message:'Application Crash'});
        //console.log(err);
        logger.error(err);
    }
}

export const register= async (request, response, next)=>{
    try{
    const user = request.body;
    const doc = await userService.register(user);
    response.status(200).json({message:'Register SuccessFully', user:doc})
    }
    catch(err){
        next(err);
        //response.status(500).json({message:'Application Crash'});
        console.log(err);
    }
    //response.send('Register');
}