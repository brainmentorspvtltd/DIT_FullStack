export const messages = {
    'login-failed':'Invalid Userid or Password',
    'login-success':'Welcome '
}