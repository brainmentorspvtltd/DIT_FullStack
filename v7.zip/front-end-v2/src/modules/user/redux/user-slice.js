import {createAsyncThunk, createSlice} from '@reduxjs/toolkit';
import { post } from '../../../shared/services/api-client';
export const register = createAsyncThunk('/register'
,async (user)=>{
    // process CRA
   const env = await import.meta.env;
    const response =  await post(env.VITE_APP_REGISTER_URL,user);
    return response.data;
});
const userSlice = createSlice({
    name:'userSlice',
    initialState:{user:{}, success:undefined, isLoading:false, message:''},
    reducers:{
       // Sync Logic 
    },
    extraReducers:(builder)=>{
        builder.addCase(register.pending,(state)=>{
            state.isLoading = true;
            state.message = 'Processing ....';
        }).addCase(register.fulfilled, (state, action)=>{
            state.isLoading = false;
            console.log('FullFilled Action is ', action);
            state.message = action.payload.message;
            state.user = action.payload.user;
            state.success = true;
        }).addCase(register.rejected, (state, action)=>{
            console.log('Rejected Action is ', action);
            state.isLoading = false;
            state.message = 'Register Fail';
            state.user = {};
            state.success = false;
        })
    }
});
export default userSlice.reducer;