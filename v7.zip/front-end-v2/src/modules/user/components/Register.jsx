import {TextField, Button} from '@mui/material';
import EmailIcon from '@mui/icons-material/Email';
import PasswordIcon from '@mui/icons-material/Password';
import PersonIcon from '@mui/icons-material/Person';
import { useRef } from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { register } from '../redux/user-slice';
export const Register = () => {
  const emailRef = useRef();
  const passwordRef = useRef();
  const nameRef = useRef();
  const dispatch = useDispatch(); // Send
  const selector = useSelector(state=>state);  // Rec
  const doRegister = ()=>{
    const email = emailRef.current.value;
    const password = passwordRef.current.value;
    const name = nameRef.current.value;
    const userInfo = {email, password, name};
    console.log('UserInfo is ',userInfo);
    dispatch(register(userInfo));
  }
  console.log('Selector Value is ', selector);
  return (
    <>
    {selector.isLoading && <p>Processing Going On....</p>}
    {selector.success===true && <p>Register SuccessFully</p>}
    {selector.success===false && <p>Register Fail</p>}
      <EmailIcon/>
      <TextField
          id="outlined-required"
          label="Email"
          inputRef={emailRef}
        />
        <br />
        <br />
        <PasswordIcon/>
        <TextField
          id="outlined-required"
          label="Password"
          type="password"
          inputRef={passwordRef}
          
        />
        <br />
        <br />
        <PersonIcon/>
        <TextField
        inputRef={nameRef}
          id="outlined-required"
          label="Name"
          
          
        />
        <br />
        <br />
        <Button onClick={doRegister} variant="contained">Register</Button>
    </>
  )
}
