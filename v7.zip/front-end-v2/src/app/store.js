import {configureStore} from '@reduxjs/toolkit';
import userReducer from '../modules/user/redux/user-slice';
// Application State
export const store = configureStore({
    reducer:userReducer
});