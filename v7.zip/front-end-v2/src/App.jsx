

import {User} from './modules/user/pages/User';
function App() {
  

  return (
    <>
        <User/>
         </>
  )
}

export default App
