// import {add} from './two.js';
const add = require('./two');
console.log('Add is ', add(10,20));
 const show = (z)=>{
    console.log('Show call');
    const r = add(10,20);
    return r * z;
}
module.exports = show;