// function add(x,y){
//     return x + y;
// }
// const sub =(x=0,y=0)=>x-y;
// exports = {add, sub};
exports.add = function add(x,y){
    return x + y;
}
exports.sub =(x=0,y=0)=>x-y;
// console.log('Three JS Loaded and Executed During require...')
// console.log(module.exports ); // {}
// // module.exports = add;
//  //module.exports = {add, sub};
//  exports = {add, sub};
// // module.exports.add = add;
// // module.exports.sub = sub;
// console.log(exports); // {}
// exports.add = function add(){
//     console.log('I am Add ');
// }
// exports.sub
//console.log(exports); // fn
module.exports = exports;
