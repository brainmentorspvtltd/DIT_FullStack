// const fn = require("./three");
// console.log('Fn is ', fn(10,20));
const obj = require('./three');
console.log(obj.add(10,20));
console.log(obj.sub(10,20));