console.log(module.exports);
console.log(exports);
console.log(module.exports === exports);