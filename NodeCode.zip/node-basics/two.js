// console.log(global);
// console.log(process);
// console.log(console);
// console.log(__dirname);
// console.log(__filename);
//console.log(arguments);
var x = 10;
console.log('X is ', x);
console.log('X is ', globalThis.x);
/*
function(exports, require, module, __filename, __dirname){
     var x = 10;
}
*/
