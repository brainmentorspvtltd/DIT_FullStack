const e = require('es-module-demo');
console.log(e(10));