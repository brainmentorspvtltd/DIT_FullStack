//import {show} from '../es-module-demo';
const show = require('../es-module-demo');
console.log(show(10));
console.log('Process Args ', process.argv[2]);