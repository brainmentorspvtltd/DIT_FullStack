import os from 'os';
import cluster from 'cluster';
import { runServer } from './server.js';
const cores  = os.cpus().length;
console.log('Number of Cores are ', cores);
//console.log('Manager ', cluster.isPrimary);
// Manager (master)
console.log('Worker ', cluster.isWorker);
if(cluster.isPrimary){
    // create child process (Worker Process)
    // cluster.fork();
    // cluster.fork();
    console.log('Manager ', cluster.isPrimary);
    for(let i = 1; i<=cores; i++){
        cluster.fork(); // node app.js
    }
}
else{
    console.log('Worker ', cluster.isWorker);
    console.log('Worker Start... ');
    // false (Worker)
    runServer();
}