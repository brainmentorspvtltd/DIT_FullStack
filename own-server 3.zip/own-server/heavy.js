export function doSomeStuff(){
    for(let i = 1; i<=100000; i++){
        for(let j =1;j<=500000; j++){
            
        }
    }
}