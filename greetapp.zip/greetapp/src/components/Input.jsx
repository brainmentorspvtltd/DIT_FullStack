export const Input = ({lbl, placeholder})=>{
    const takeInput = (event)=>{
        console.log('Input Rec ', event.target.value);
    }
    return (<div className="form-group">
        <label>{lbl}</label>
        <input onChange={takeInput} className="form-control" type='text' placeholder={placeholder}/>
    </div>)
}