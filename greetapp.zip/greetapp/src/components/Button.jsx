export const Button = ({msg,cssclass})=>{
    return (<button className={cssclass}>{msg}</button>)
}