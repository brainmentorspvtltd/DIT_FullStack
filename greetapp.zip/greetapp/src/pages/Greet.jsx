import { Button } from "../components/Button";
import { Input } from "../components/Input";
import { Message } from "../components/Message";

export const Greet = ()=>{
    const message = ""; // Welcome FirstName+LastName
    return (<div>
            <Message msg="Greet App" myclass ="info"/>
            <Input lbl='First Name' placeholder='Type First Name'/>
            <Input lbl = 'Last Name' placeholder='Type Last Name'/>
            <Button msg='Greet' cssclass='btn btn-primary me-2'/>
            <Button msg='Clear All' cssclass='btn btn-secondary'/>
            {message && <Message msg="Welcome" myclass="success"/>}
    </div>);
}