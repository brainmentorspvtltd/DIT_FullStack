import {useDispatch} from 'react-redux';
const Button = ({value, action})=>{
    const dispatch = useDispatch();
    return (<button onClick={()=>{
        console.log('Button Value is ', value);
        dispatch(action((value==='+'?1:-1)));
    }} className = 'btn btn-primary'>{value}</button>)
}
export default Button;