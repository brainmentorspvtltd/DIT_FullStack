What is CSS (Cascade Style Sheet)?
CSS is a language for how document(HTML Page) will be presented to the 
end-user.
- Used to Style and Layout web pages.
- Font Color, Background Color, Content Spacing, 
Split to Multiple Row and Column, Animations, Margin, Padding

Why it is called Cascade Style Sheet
In ur Web Page , we have lot of Styles
Cascade - Set of Rules & Process to find out which style would be
apply to ur document.

CSS - Rule Based Language
