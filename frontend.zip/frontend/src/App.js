import logo from './logo.svg';
import './App.css';
import { UserPage } from './modules/user/pages/UserPage';

function App() {
  return (
   <UserPage/>
  );
}

export default App;
