import Button from '@mui/material/Button';
import VpnKeyIcon from '@mui/icons-material/VpnKey';
export const OAuth = ()=>{
    return (<Button variant="contained"><VpnKeyIcon/>&nbsp;Login with Google</Button>)
}