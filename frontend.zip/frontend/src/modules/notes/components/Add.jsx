import React from 'react'
import { useParams } from 'react-router-dom'
/*
  Add and Update Screen is Same
*/
const Add = () => {
  const params = useParams();
  console.log('Params are ', params);
  return (
    <div>
      <h1>{params.operationname} Note</h1>
    </div>
  )
}

export default Add