import fs from 'fs';
import { __dirname } from './abs-path.js';
import path from 'path';
export function serveStaticContent(urlString, response){
    const rootDir  = __dirname;
    const fullPath = path.join(rootDir, '/public/',urlString);
    const stream = fs.createReadStream(fullPath);
    stream.pipe(response);
}
export function isStaticContent(urlString){
    const extensions = [".css",".js",".html",".png",".jpeg","jpg",".ico"];
    const rootDir  = __dirname;
    const fullPath = path.join(rootDir, '/public/',urlString);
    const ext = path.extname(fullPath);
    console.log('Extension is ',ext, ' Path is ', fullPath);
    return extensions.indexOf(ext)>=0;
    // index.html , /images/xyz.png
}