import http from 'http';
import dotenv from 'dotenv';
import chalk from 'chalk';
//import url from  'url';
import querystring from 'querystring';
import { isStaticContent, serveStaticContent } from './serve-content.js';
function handleRequestAndResponse(request, response){
    const urlString = request.url; // /
    const method = request.method;
    console.log('Request URL is ', request.url);
    if(urlString==='/'){
        serveStaticContent('index.html', response);
    }
    else if(isStaticContent(urlString)){
        serveStaticContent(urlString, response);
    }
    else if(urlString.startsWith('/login') && method==='GET'){
        const urlSearchParams = new URLSearchParams(urlString);
        const userInfo = [];
        for(let e of urlSearchParams.entries()){
            console.log('E is ',e[1]);
            userInfo.push(e[1]);
        }
        console.log('UserInfo is ', userInfo);
        const [userid, pwd] = userInfo;
        // const result = url.parse(urlString, true);
        // const {userid, pwd} = result.query;
        if(userid === pwd){
            response.write(`<h1>Welcome ${userid}</h1>`);
            response.end();
        }
        else{
            response.write(`<h1>Invalid Userid or password </h1>`);
            response.end();
        }
        //console.log('Result is ', result);
       
    }
    else if(urlString==='/login' && method==='POST'){
        let data = '';
        request.on('data', chunk=>{
            data +=chunk;
        });
        request.on('end',()=>{
            //response.writeHead(200,{'Content-Type':'text/html'});
            console.log('Data Rec from POST ', data);
            const obj = querystring.parse(data);
            console.log('Object is ', obj);
            const {userid , pwd} = obj;
            if(userid === pwd){
               // response.write(`<h1>Welcome ${userid}</h1>`);
               
               response.writeHead(302,{'Location':'/dashboard'});
               response.end();
            }
            else{
                response.write(`<h1>Invalid Userid or password </h1>`);
                response.end();
            }
        })

    }
    else if(urlString==='/dashboard'){
        response.write('<h1>Welcome to the DashBoard </h1>');
        response.end();
    }
    else if(urlString=='/api'){
        response.writeHead(200,{'Content-Type':'application/json'});
        response.write(JSON.stringify({id:1001,name:'Amit', city:'Delhi'}));
        response.end();
    }
    else {
    console.log('Request Rec ', request.url);
    response.write('<h1>Hello Client </h1>');
    response.end();
    }
}
const server = http.createServer(handleRequestAndResponse);
dotenv.config();
// console.log(process.env);
const serverInfo = server.listen(process.env.PORTNO || 3333,err=>{
    if(err){
        //console.log('Server Crash ', err);
        console.log(chalk.red.bold('Server Crash Happens.... '), err);
    }
    else{
        console.log(chalk.green.bold.underline('Server Up and Running '), serverInfo.address().port);
        //console.log('Server Up and Running ', serverInfo.address().port);
    }
})