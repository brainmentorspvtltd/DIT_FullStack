import { userService } from "../services/user-service.js"

export const register= async (request, response, next)=>{
    try{
    const user = request.body;
    const doc = await userService.register(user);
    response.status(200).json({message:'Register SuccessFully', user:doc})
    }
    catch(err){
        response.status(500).json({message:'Application Crash'});
        console.log(err);
    }
    //response.send('Register');
}