import express from 'express';
import { register } from '../controllers/user-controller.js';
export const userRoute = express.Router();
userRoute.post('/register',register);