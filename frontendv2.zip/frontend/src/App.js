import logo from './logo.svg';
import './App.css';
import { UserPage } from './modules/user/pages/UserPage';
import {Route, Routes} from 'react-router-dom';
import { NoteDashBoard } from './modules/notes/pages/NoteDashBoard';
function App() {
  return (
    <Routes>
        <Route path='/' element={<UserPage/>}/>
        <Route path='/dashboard'  element={<NoteDashBoard/>}/>
    </Routes>
   
  );
}

export default App;
