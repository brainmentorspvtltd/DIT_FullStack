import React from 'react'

export const NoteDashBoard = () => {
  return (
    <div>NoteDashBoard</div>
  )
}
