export const error404 = (request, response, next)=>{
    response.status(404).send("<h2>OOPS U Type Something Else... ");
}