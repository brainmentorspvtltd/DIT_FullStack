import express from 'express';
import chalk from 'chalk';
import dotenv from 'dotenv';
import { error404 } from './utils/middlewares/404.js';
import { userRoutes } from './routes/user-routes.js';
const app = express();
dotenv.config();
app.use(express.static('public'));
app.use('/', userRoutes);
//app.use(middleware)
// Routing
// app.get('/welcome',(request, response)=>{
//     response.send('<h1>Hello I am Express JS </h1>');
// })
app.use(error404);
const server = app.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log(chalk.red.bold('Server Crash '), err);
    }
    else{
        console.log(chalk.greenBright.bold.underline('Server Up and Running '),
         server.address().port);
    }
})
