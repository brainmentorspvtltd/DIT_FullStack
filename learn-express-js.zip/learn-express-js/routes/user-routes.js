import express from 'express';
export const userRoutes = express.Router();
userRoutes.get('/profile', (request, response)=>{
    response.send('Profile');
});
userRoutes.post('/register',(request, response)=>{
    response.send('Register');
});
userRoutes.put('/change-password',(request, response)=>{
    response.send('Change Password');
});
userRoutes.delete('/remove-account', (request, response)=>{
    response.send('Remove Account');
})
