import React from 'react'
import { useParams } from 'react-router-dom'
import {Button, TextField} from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { useRef , useState} from 'react';
import { useContext } from 'react';
import { NoteContext } from '../context/note-context';
/*
  Add and Update Screen is Same
*/
const Add = () => {
  const [message , setMessage] = useState('');
  const params = useParams();
  console.log('Params are ', params);
  const nameRef = useRef();
  const descRef = useRef();
  const dateRef = useRef();
  const noteContext = useContext(NoteContext);
  const takeInput = ()=>{
        const noteObject = {
             title : nameRef.current.value,
             desc : descRef.current.value,
             date:dateRef.current.value
        } 
        noteContext.addSingleNote(noteObject); 
        console.log('Input is ', noteObject);
        setMessage('Note Added....');
  }
  return (
    <div>
      <h1>{params.operationname} Note {message}</h1>
      <TextField inputRef = {nameRef} id="outlined-basic" label="Title" variant="outlined" />
      <br/>    <br/>    <br/>
      <TextField
      inputRef = {descRef}
          id="outlined-multiline-static"
          label="Desc"
          multiline
          rows={4}
          
        />
        <br/> <br/> 
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker inputRef={dateRef} label="Note Date" />
        </LocalizationProvider>

        <br/> <br/>
        <Button onClick={takeInput} variant="contained">Add Note</Button>


    </div>
  )
}

export default Add