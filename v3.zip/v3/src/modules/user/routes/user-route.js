import express from 'express';
import { register } from '../controllers/user-controller.js';
import { validate } from '../../../shared/middlewares/validation-middleware.js';
import { userValidationSchema } from '../validations/user-validation.js';
export const userRoute = express.Router();
userRoute.post('/register',validate(userValidationSchema),register);
//userRoute.post('/register',register);