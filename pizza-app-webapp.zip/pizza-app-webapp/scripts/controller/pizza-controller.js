import { getPizzas } from "../services/pizza-operations.js";
async function printPizzas(){
    const allPizzas = await getPizzas();
    console.log('All Pizza ', allPizzas);
}
printPizzas();
