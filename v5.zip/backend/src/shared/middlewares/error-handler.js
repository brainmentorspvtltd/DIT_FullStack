import { myLogger } from "../logs/app-logs.js";


export const errorHandler = (err, request, response, next)=>{
    const logger = myLogger('error-handler');
    if(err){
        logger.error('Error is '+ err.message +" "+err.stack);
        response.status(500).json({
            message:err.message,
            stack:err.stack
        })
    }
    else{
        next();
    }
}