const pendingTimers = [];
const osTask = [];
const longRunningTask = [];
function isPendingSomeThing(){
    return pendingTimers.length>0 || osTask.length>0 || longRunningTask.length>0;
}
while(isPendingSomeThing()){
    console.log('Event Loop Keep Running....');
}