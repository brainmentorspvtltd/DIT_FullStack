const fs = require('fs'); // Sync
console.log('Example of Node JS '); // Sync
fs.readFile(__filename, (err, buffer)=>{
    if(err){
        console.log('Error is ', err);
    }
    else{
        console.log('Data is ', buffer.toString());
    }
}) ; // Async
const path = '/Users/amitsrivastava/Documents/node-all-codes/core/simulate-el.js';
fs.readFile(path, (err, buffer)=>{
    if(err){
        console.log('Error in Second File read ', err);
    }
    else{
        console.log('Data Arrives ', buffer.toString());
    }
})
console.log('Code Ends');