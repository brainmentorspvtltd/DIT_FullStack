const events = require('events');
const event = new events.EventEmitter();
// Event Listener
event.on('ring', (val)=>{
    console.log('Ring ring event fire.....', val);
})
event.on('ring', val=>{
    console.log('Ring2 Event Fire.... ', val);
})
console.log('Max Listeners ', event.getMaxListeners());
event.setMaxListeners(20);
console.log('Event Going to be Fire....');
event.emit('ring', 'Iphone'); // Event Fire
event.emit('ring', 'Samsung');