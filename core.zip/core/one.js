// Register the exit event
process.on('uncaughtException', (err)=>{
    // Log it in some file (Logger)
    // Email the Error
    console.log('Some Problem Occur ', err);
})
// process.on('exit',(code)=>{
//     console.log('Process Exit... ', code);
// })

console.log(process.cwd());
throw new Error('Some Error ....');
console.log(process.env.USER);
console.log(process.env.HOME);