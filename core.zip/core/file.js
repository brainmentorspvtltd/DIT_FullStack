const fs = require('fs');
const filePath = '/Users/amitsrivastava/Documents/softwares/jammy-desktop0ubuntu-arm64.iso';
console.log('Going to read a Big File...');
// fs.readFile(filePath, (err, buffer)=>{
//     if(err){
//         console.log('Error ', err);
//     }
//     else{
//         console.log(buffer);
//     }
// });
const path2 = '/Users/amitsrivastava/Documents/softwares/jammy-desktop0ubuntu-arm64copy.iso';
const stream = fs.createReadStream(filePath);
const wstream = fs.createWriteStream(path2);
stream.pipe(wstream);
// stream.on('open', ()=>{
//     console.log('Stream Open...');
//     console.log('Copy Start...');
// });
// stream.on('data', chunk=>{
//     //console.log("Data Rec ", chunk);
//     wstream.write(chunk);
// })
// stream.on('end', ()=>{
//     console.log('Stream Ends ');
//     console.log('Copy Ends');
// })
// stream.on('close', ()=>{
//     console.log('Stream close')
// })