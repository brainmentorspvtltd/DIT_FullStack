console.log('Program Start');
setTimeout(()=>{
    console.log('Run After 10 Sec ')
}, 1000 * 10);
var a = 10;
var b = 20;
var c = a + b;
console.log('Sum is ', c);