import axios from 'axios';
export const post = async (URL, data)=>{
    try{
    return await axios.post(URL, data);
    }
    catch(err){
        console.log('Post Request Failed ', URL);
        throw err;
    }
}

export const get = async (URL)=>{
    try{
        return await axios.get(URL);
        }
        catch(err){
            console.log('Get Request Failed ', URL);
            throw err;
        }
}