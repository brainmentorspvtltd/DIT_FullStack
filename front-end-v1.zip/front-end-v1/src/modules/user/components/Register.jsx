import {TextField, Button} from '@mui/material';
import EmailIcon from '@mui/icons-material/Email';
import PasswordIcon from '@mui/icons-material/Password';
import PersonIcon from '@mui/icons-material/Person';
import { useRef } from 'react';
export const Register = () => {
  const emailRef = useRef();
  const passwordRef = useRef();
  const nameRef = useRef();
  const doRegister = ()=>{
    const email = emailRef.current.value;
    const password = passwordRef.current.value;
    const name = nameRef.current.value;
    const userInfo = {email, password, name};
    console.log('UserInfo is ',userInfo);
  }
  return (
    <>
      <EmailIcon/>
      <TextField
          id="outlined-required"
          label="Email"
          inputRef={emailRef}
        />
        <br />
        <br />
        <PasswordIcon/>
        <TextField
          id="outlined-required"
          label="Password"
          type="password"
          inputRef={passwordRef}
          
        />
        <br />
        <br />
        <PersonIcon/>
        <TextField
        inputRef={nameRef}
          id="outlined-required"
          label="Name"
          
          
        />
        <br />
        <br />
        <Button onClick={doRegister} variant="contained">Register</Button>
    </>
  )
}
