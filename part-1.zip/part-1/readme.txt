What is CSS3?
Cascade Style Sheet 3 - Latest Version of CSS.
Level 3 of CSS.

New Features:
a) Border
b) Gradient
c) Text Overflow
d) Shadows
e) Animation , Transitions
f) Flex, Grids, Media Queries

Divide into 3 Sections
a) What is New/ Latest in CSS3 
i) Box Model
ii) Advance Selectors (checked , target)
iii) Borders
iv) Backgrounds
v) Shadows
vi) New Units
vii) Functions (e.g var, calc )

b) Animations in CSS3
i) Transformation
ii) Transitions
iii) Perspective
iv) KeyFrames

c) Responsive Web Design (RWD)
i) Column Layouts
ii) Flex
iii) Grids
iv) Media Queries