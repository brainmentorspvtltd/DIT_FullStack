import { Container } from "@mui/material";
import { OAuth } from "../components/OAuth"

export const UserPage = ()=>{
    return (
    <Container>
        <OAuth/>
    </Container>
    );
}