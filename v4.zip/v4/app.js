// Represent an Application 
// https://dontpad.com/dit-code
import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { createConnection } from './src/shared/db/connection.js';
import { userRoute } from './src/modules/user/routes/user-route.js';
const app = express();
dotenv.config();

app.use(express.json()); 
app.use('/', userRoute);


const promise = createConnection();
promise.then(data=>{
    console.log('DB Connection Done...');
    app.listen(1234,err=>{
        if(err){
            console.log('Server Crash ', err);
        }
        else{
            console.log('Server Up and Running');
        }
    })
}).catch(err=>{
    console.log('Error in DB Connection ', err);
})

// app.use(middleware);
// middleware - function (req, res, next)
